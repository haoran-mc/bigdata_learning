package com.weather;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;
//每小时各种污染物总量 北京： 0～24点各种污染物总量浓度的和
public class anaMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, DoubleWritable> {
	//private final static IntWritable one = new IntWritable(1);

	public void map(LongWritable key, Text value, OutputCollector<Text, DoubleWritable> output, Reporter reporter) throws IOException {

		String valueString = value.toString();
		String[] SingleTimeData = valueString.split("\\s+");
		DoubleWritable val = new DoubleWritable(Double.parseDouble(SingleTimeData[3]));
		//output.collect(new Text(SingleTimeData[3]), one);
		output.collect(new Text(SingleTimeData[1]), val);
	}
}
